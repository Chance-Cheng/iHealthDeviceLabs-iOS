//
//  HSHeader.h
//  HSDemoCode
//
//  Created by zhiwei jing on 14-7-28.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#ifndef HSDemoCode_HSHeader_h
#define HSDemoCode_HSHeader_h

#import "User.h"
#import "HS3.h"
#import "HS4.h"
#import "HS5.h"
#import "HS3Controller.h"
#import "HS4Controller.h"
#import "HS5Controller.h"
#import "HSMacroFile.h"
#import "iHealthHS6.h"
#endif
